
import keyboard
import pyautogui

def press_space(event):
    print (event.name)
    if event.name == 'space':
        pyautogui.hotkey('delete', 'shiftright', 'r')
        #pyautogui.press('capslock')

keyboard.on_press(press_space)

print("Press space to trigger 'Caps Lock'. Press 'Ctrl + C' to exit.")

keyboard.wait('esc')
